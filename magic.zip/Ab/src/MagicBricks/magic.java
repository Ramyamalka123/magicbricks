package MagicBricks;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class magic {

	public static void main(String[] args) throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("disable-notifications");
		WebDriver driver = new ChromeDriver(options);
		driver.get("https://www.magicbricks.com/property-for-sale-rent-in-Vijayawada/residential-real-estate-Vijayawada/?frmapp=yes");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		//driver.findElement(By.xpath("//div[@class='mb-search__tag-close']")).click();
		//city
		driver.findElement(By.xpath("//input[@id='keyword']")).sendKeys("Hyderabad");
		
		//WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		//List<WebElement> vjy = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[text()='Vijayawada']")));
		
		//for(WebElement suggestions :vjy) {
			
		//}
		///
		//flat
		driver.findElement(By.xpath("(//div[@class='mb-search__title'])[1]")).click();	
		//house/villa and 2bhk
		//driver.findElement(By.xpath("//label[text()='House/Villa']")).click();
		driver.findElement(By.xpath("//label[text()='Flat']")).click();
        driver.findElement(By.xpath("//label[@id='11702']")).click();
        //budget
        driver.findElement(By.xpath("//span[text()='Budget']")).click();
        //10lakhs
        driver.findElement(By.xpath("(//div[text()='₹10 Lac'])[1]")).click();
        //max
        driver.findElement(By.xpath("(//input[@type='text'])[4]")).click();
        //70lakhs
        driver.findElement(By.xpath("(//div[text()='₹70 Lac'])[2]")).click();
        //search
        driver.findElement(By.xpath("//div[@class='mb-search__btn']")).click();
        Thread.sleep(9000);        
        
   }

}